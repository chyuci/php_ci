<?php
/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: testyang $
 * $Id: fckfile_manage.php 14481 2008-04-18 11:23:01Z testyang $
 */
$_LANG['fckfile_manage'] = 'Fck上传文件管理';
$_LANG['file_manage'] = '文件目录管理';
$_LANG['image_manage'] = '图片目录管理';
$_LANG['flash_manage'] = 'FLASH目录管理';
$_LANG['media_manage'] = '多媒体目录管理';
$_LANG['fck_file_list'] = 'FCK目录列表';
$_LANG['file_id'] = '编号';
$_LANG['button_remove'] = '批量删除';
$_LANG['no_select_file'] = '您没有选择任何文件';
$_LANG['back_list'] = '返回文件列表';
$_LANG['batch_remove_succeed'] = '您已经成功删除 %d 个文件';

$_LANG['edit'] = '编辑';
$_LANG['item_url'] = '链接地址';
$_LANG['item_vieworder'] = '排序';
$_LANG['top'] = '顶部';
$_LANG['middle'] = '中间';
$_LANG['bottom'] = '底部 ';
$_LANG['edit_ok'] = '操作成功';
$_LANG['go_list'] = '返回列表';
$_LANG['ckdel'] = '确定删除?';

$_LANG['namecannotnull'] = '请输入导航栏名称！';
$_LANG['linkcannotnull'] = '请输入链接地址！';

$_LANG['notice_url'] = '如果是本站的网址，可缩写为与商城根目录相对地址，如index.php；<br>其他情况都应该输入完整的网址，如http://www.ecshop.com/';
?>