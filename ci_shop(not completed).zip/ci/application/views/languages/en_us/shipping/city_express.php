<?php

/**
 * ECSHOP Inter-city shipping plug-in's language file
 * ============================================================================
 * All right reserved (C) 2005-2011 Beijing Yi Shang Interactive Technology
 * Development Ltd.
 * Web site: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * This is a free/open source software；it means that you can modify, use and
 * republish the program code, on the premise of that your behavior is not for
 * commercial purposes.
 * ============================================================================
 * $Author: liubo $
 * $Id: city_express.php 17217 2011-01-19 06:29:08Z liubo $
*/

$_LANG['city_express']        = 'Inter-city shipping';
$_LANG['city_express_desc']   = 'Cost of shipping is fixed ';
$_LANG['base_fee']      = 'Basic expenditure:';
?>
