<?php

/**
 * ECSHOP 会员资金管理文件
 * ============================================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * $Author: sunxiaodong $
 * $Id: user_account_manage.php 15487 2008-12-22 09:32:06Z sunxiaodong $
*/

$_LANG['user_account_manage'] = 'fund management';
$_LANG['view_application'] = 'Show application record';
$_LANG['surplus_pro_type'] = 'type';
$_LANG['repay_money'] = 'mention is the amount of';
$_LANG['money'] = 'amount';
$_LANG['username'] = 'Member Name';
$_LANG['add_money'] = 'top-up payments';
$_LANG['payment'] = 'top-up mode';
$_LANG['add_money_time'] = 'recharge time';
$_LANG['to_cash'] = 'mention is the amount of';
$_LANG['to_payment'] = 'mention is the way';
$_LANG['to_cash_time'] = 'mention is the time';
$_LANG['button_remove'] = 'Delete';
$_LANG['remove_confirm'] = 'Are you sure you want to delete the member account you?';
$_LANG['order_by_surplus'] =' Order List ';
$_LANG['label_user_name'] = 'Member Name';
$_LANG['order_sn'] = 'order number';
$_LANG['surplus'] =' balance ';
$_LANG['integral_money'] = 'points balance';
$_LANG['add_time'] = 'orders-time';
$_LANG['view_order'] = 'view orders';
$_LANG['user_account_info'] = 'Member account information';
$_LANG['user_add_money'] = 'users to recharge the total';
$_LANG['user_repay_money'] = 'mention is the amount of';
$_LANG['user_money'] = 'users available funds';
$_LANG['frozen_money'] = 'users to freeze the funds';
$_LANG['surplus_info'] = 'balance of the use of information';
$_LANG['order_surplus'] =' trade balance ';
$_LANG['integral_money'] = 'points balance';
$_LANG['view'] = 'Show';

?>