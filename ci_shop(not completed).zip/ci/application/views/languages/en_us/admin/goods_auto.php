<?php

/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: goods_auto.php 17217 2011-01-19 06:29:08Z liubo $
 */
$_LANG['id'] = 'id';

$_LANG['starttime'] = 'Was added to our catalog';
$_LANG['endtime'] = 'Under the time frame';
$_LANG['select_time'] = 'Please select the time';
$_LANG['goods_name'] = 'Trade names';
$_LANG['ok'] = 'Determine';
$_LANG['edit_ok'] = 'Successful operation';
$_LANG['delete'] = 'Revocation';
$_LANG['deleteck'] = 'Delete this merchandise to determine the automatic shelves shelves deal with it? This action will not affect the product itself';
$_LANG['enable_notice'] = 'You need to system settings -> plans to open mission in order to use this feature.';
$_LANG['button_start'] = 'Volume was added to our catalog';
$_LANG['button_end'] = 'Volume under the plane';

$_LANG['no_select_goods'] = 'Not selected merchandise';

$_LANG['batch_start_succeed'] = 'Volume shelves success';
$_LANG['batch_end_succeed'] = 'Volume under the plane success';

$_LANG['back_list'] = 'Merchandise automatically back up and down plane';
?>
