<?php
// database host
$db_host   = "localhost:3306";

// database name
$db_name   = "ecshop";

// database username
$db_user   = "root";

// database password
$db_pass   = "c1y2c3";

// table prefix
$prefix    = "ecs_";

$timezone    = "Europe/Paris";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('EC_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');

define('API_TIME', '2017-02-21 06:53:08');

?>