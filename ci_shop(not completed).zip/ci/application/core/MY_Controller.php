<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//定义前台控制器
class Home_Controller extends CI_Controller{

	/**
	 * [__construct 构造方法]
	 */
	public function __construct() {
		parent::__construct();
		//开启皮肤功能
		$this->load->switch_themes_on();
	}
}
//定义后台控制器
class Admin_Controller extends CI_Controller{

	/**
	 * [__construct 构造方法]
	 */
	public function __construct() {
		parent::__construct();
		//开启皮肤功能
		$this->load->switch_themes_off();
		$sess_name = $this->session->admin;
		$this->checkUser($sess_name);
	}

	public function checkUser($username) {
		if (!isset($username)) {
			redirect('admin/privilege/login');
		}
	}
}