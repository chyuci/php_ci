<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Goods_model extends CI_Model {

	public function count_goods() {
		$row = $this->db->query("SELECT count(*) as num FROM ci_goods")->row_array();
		return $row['num'];
	}

	public function list_goods($limit, $offset) {
		$query = $this->db->limit($limit, $offset)->get('ci_goods');
		return $query->result_array();
	}

	public function best_goods() {
		$map['is_best'] = 1;
		$map['is_onsale'] = 1;
		$query = $this->db->where($map)->get('ci_goods');
		return $query->result_array();
	}

	public function new_goods() {
		$map['is_new'] = 1;
		$map['is_onsale'] = 1;
		$query = $this->db->where($map)->get('ci_goods');
		return $query->result_array();
	}

	public function hot_goods() {
		$map['is_hot'] = 1;
		$map['is_onsale'] = 1;
		$query = $this->db->where($map)->get('ci_goods');
		return $query->result_array();
	}

	public function get_goods($goods_id) {
		$map['goods_id'] = $goods_id;
		$query = $this->db->where($map)->get('ci_goods');
		return $query->row_array();
	}

	public function getParents($cat_id) {
		$res = array();
		while ($cat_id) {
			$cat = $this->db->where(array('cat_id'=>$cat_id))->get('ci_category')->row_array();
			$res[] = array(
				'cat_id' => $cat['cat_id'],
				'cat_name' => $cat['cat_name'],
			);
			// 改变条件
			$cat_id = $cat['parent_id'];
		}
		
		return array_reverse($res);
	}

	public function get_cat($goods_id) {
		$query = $this->db->where(array('goods_id'=>$goods_id))->get('ci_goods');
		return $query->row_array();
	}

}