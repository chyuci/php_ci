<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Goodstype_model extends CI_Model {
	public function count_goodstype() {
		$row = $this->db->query("SELECT count(distinct a.type_id) as num FROM ci_goods_type AS g INNER JOIN ci_attribute AS a ON g.type_id = a.type_id")->row_array();
		return $row['num'];
	}

	public function list_goodstype($limit, $offset) {
		$query = $this->db->limit($limit, $offset)->get('ci_goods_type');
		return $query->result_array();
	}

	public function get_goodstype_attr($limit, $offset) {
		$query = $this->db
		->select('g.type_id, `type_name`, count(*) as `num`')
		->from('ci_attribute as a')
		->join('ci_goods_type as g', 'a.type_id = g.type_id')
		->group_by('type_id')
		->limit($limit, $offset)
		->get();
		return $query->result_array();
	}
}