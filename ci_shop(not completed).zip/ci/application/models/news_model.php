<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News_model extends CI_Model {
	
	/**
	 * [__construct 构造方法]
	 */
	public function __construct() {
		//调用父类构造方法
		parent::__construct();

		// 由于在application/config/autoload.php中$autoload['libraries'] = array('database');进行了自动载入配置所以不用在手动载入数据库类
	}

	/**
	 * [add_news 添加新闻]
	 */
	public function add_news($data) {
		//使用AR类完成插入操作
		return $this->db->insert('news', $data);
	}

	/**
	 * [show_news 显示新闻]
	 * @return [type] [查询结果集]
	 */
	public function show_news() {
		$query = $this->db->get('news');
		return $query->result_array();
	}

	/**
	 * [find_one 获取单条记录]
	 * @param  [type] $id [新闻id]
	 * @return [type]     [description]
	 */
	public function find_one($id) {
		$query = $this->db->where('id = ' . $id)->get('news');
		$result = $query->result_array();
		$rows = array();
		foreach($result as $row) {
			$rows = $row;
		}
		return $rows;
	}

	/**
	 * [update_news 修改新闻]
	 * @param  [type] $id [新闻id]
	 * @return [type]     [description]
	 */
	public function update_news($data) {
		return $this->db->where('id', $data['id'])->update('news', $data);
	}

	public function del_news($id) {
		return $this->db->where('id', $id)->delete('news');
	}

}