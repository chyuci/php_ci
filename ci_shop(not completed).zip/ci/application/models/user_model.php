<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
	public function get_pwd($username) {
		$map['user_name'] = $username;
		$query = $this->db->where($map)->get('ci_user');
		return $query->row_array()['password'];
	}
}