<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Category_model extends CI_Model {
	//构造方法
	public function __construct() {
		parent::__construct();
	}
	//获取递归树的内容
	public function catTree() {
		$query = $this->db->get('ci_category');
		$cats = $query->result_array();
		return $this->_tree($cats);
	}
	//形成递归树
	private function _tree($arr, $pid=0, $level=0) {
		static $tree = array();
		foreach($arr as $v) {
			if ($v['parent_id'] == $pid) {
				//找到父类进行保存
				$v['level'] = $level;
				$tree[] = $v;
				//继续向下查找
				$this->_tree($arr, $v['cat_id'], $level+1);
			}
		}
		return $tree;
	}
	/**
	* getSubids 查找当前分类及其子类
	* @param  integer $cat_id 分类id
	* @return array         当前分类及其子类构成的数组
	*/
	public function getSubids($cat_id) {
		$query = $this->db->get('ci_category');
		$cats = $query->result_array();
		$list = $this->_tree($cats, $cat_id);
		$res = array();
		foreach($list as $val) {
			$res[] = $val['cat_id'];
		}
		$res[] = $cat_id;
		return $res;
	}
	/**
	* child 获取某节点下面的直接子分类
	* @param  array  $arr 数组
	* @param  integer $pid 父类id
	* @return array       数组
	*/
	public function child($arr, $pid=0) {
		$child = array();
		foreach($arr as $k => $v) {
			if ($v['parent_id'] == $pid) {
				$child[] = $v;
			}
		}
		return $child;
	}
	/**
	* cate_list 对于给定数组构造三维数组
	* @param  array  $arr 分类记录
	* @param  integer $pid 父级分类
	* @return array
	*/
	public function cate_list($arr, $pid=0) {
		//获取顶级分类的子类即$pid=0的子类
		$child = $this->child($arr, $pid);
		if (empty($child)) {
			return null;
		}
		foreach($child as $k => $v) {
			$current_child = $this->cate_list($arr, $v['cat_id']);
			if ($current_child != null) {
				$child[$k]['child'] = $current_child;
			}
		}
		return $child;
	}
	/**
	* 获取前台分类数据，三维数组形式
	*/
	public function front_cate() {
		$query = $this->db->get('ci_category');
		$cates = $query->result_array();
		return $this->cate_list($cates);
	}
}