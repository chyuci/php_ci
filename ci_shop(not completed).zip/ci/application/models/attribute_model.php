<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attribute_model extends CI_Model {
	public function count_attribute($type_id) {
		$row = $this->db->query("SELECT count(*) as num FROM ci_attribute WHERE type_id=$type_id")->row_array();
		return $row['num'];
	}

	public function list_attribute($type_id, $limit, $offset) {
		$query = $this->db
		->select('`attr_id`, `attr_name`, a.`type_id`, `attr_type`, `attr_input_type`, `attr_value`, `sort_order`, `type_name`')
		->from('ci_attribute as a')
		->join('ci_goods_type as g', 'a.type_id = g.type_id')
		->where(array('a.type_id'=>$type_id))
		->limit($limit, $offset)
		->get();
		return $query->result_array();
	}

	public function getAttrForm($type_id) {
		//获取所有属性
		$map['type_id'] = $type_id;
		$query = $this->db->where($map)->get('ci_attribute');
		$attrs = $query->result_array();
		$res = "";
		$res .= "<table width='100%' id='attrTable'>";
		$res .= "<tbody>";

		foreach($attrs as $attr) {
			$res .= "<tr>";
			$res .= "<td class='label'>{$attr['attr_name']}</td>";
			$res .= "<td>";
			$res .= "<input type='hidden' name='attr_id_list[]' value='".$attr['attr_id']."'>";
			switch($attr['attr_input_type']){
				case 0:
					#文本框
					$res .= "<input name='attr_value_list[]' type='text' value='' size='40'>";
					break;
				case 1:
					#下拉列表
					$res .= "<select name='attr_value_list[]'>";
					$res .= "<option value=''>请选择...</option>";
					$opts = explode(PHP_EOL, $attr['attr_value']);
					foreach($opts as $opt) {
						$res .= "<option value='$opt'>$opt</option>";
					}
					$res .= "</select>";
					break;
				case 2:
					#文本域
				
				break;
			}


			$res .= "<input type='hidden' name='attr_price_list[]' value='0'>";
			$res .= "</td>";
			$res .= "</tr>";
		}
		$res .= "</tbody>";
		$res .= "</table>";
		return $res;
	}
}