<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Goods extends Admin_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('goods_model');
		$this->load->model('goodstype_model');
		$this->load->model('category_model');
		$this->load->model('brand_model');
		$this->load->model('attribute_model');
	}

	//显示品牌信息
	public function index($offset='') {

		$cat_id = $this->input->post('cat_id');
		$brand_id = $this->input->post('brand_id');
		$intro_type = $this->input->post('intro_type');
		$is_on_sale = $this->input->post('is_on_sale');
		$keyword = $this->input->post('keyword');
		$config['base_url'] = site_url('admin/goods/index');
		$config['total_rows'] = $this->goods_model->count_goods();
		$config['per_page'] = 4;
		$config['uri_segment'] = 4;//uri第四段为偏移量
		$config['first_link'] = '首页';//首页
		$config['last_link'] = '尾页';//尾页
		$config['prev_link'] = '上一页';//上一页
		$config['next_link'] = '下一页';//下一页
		$this->pagination->initialize($config);
		$limit = $config['per_page'];
		if((is_null($cat_id) and is_null($brand_id) and is_null($intro_type) and is_null($is_on_sale) and is_null($keyword))||(empty($cat_id) and empty($brand_id) and empty($intro_type) and ($is_on_sale=='') and empty($keyword))) {
			$this->db->where('1=1');
		} else {
			$map = array();
			$likes = array();
			if(!empty($cat_id)) $map['cat_id'] = $cat_id;
			if(!empty($brand_id)) $map['brand_id'] = $brand_id;
			if(!empty($intro_type)) {
				if($intro_type == 'is_best') {
					$map['is_best'] = 1;
				} 
				if($intro_type == 'is_promote') {
					$map['is_promote'] = 1;
				} 
				if($intro_type == 'is_hot') {
					$map['is_hot'] = 1;
				} 
				if($intro_type == 'is_new') {
					$map['is_new'] = 1;
				} 

			}
			if($is_on_sale!='') $map['is_onsale'] = $is_on_sale;
			if(!empty($keyword)) $likes['goods_name'] = $keyword;
			
			$this->db->like($likes)->where($map);
		}
		
		$data['goods'] = $this->goods_model->list_goods($limit, $offset);
		$data['cats'] = $this->category_model->catTree();
		$query = $this->db->get('ci_brand');
		$data['brands'] = $query->result_array();
		$data['pageinfo'] = $this->pagination->create_links();
		$this->load->view('goods_list.html', $data);
	}
	//显示添加表单
	public function add() {
		$data['cats'] = $this->category_model->catTree();
		$query = $this->db->get('ci_brand');
		$data['brands'] = $query->result_array();
		$query = $this->db->get('ci_goods_type');
		$data['types'] = $query->result_array();
		$this->load->view('goods_add.html', $data);
	}
	//添加品牌业务逻辑处理
	public function insert() {
		$_validate = array(
			array(
				'field' => 'goods_name',
				'label' => '商品名称',
				'rules' => 'required'
			)
		);
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/goods/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['goods_name'] = $this->input->post('goods_name');
			$data['goods_sn'] = $this->input->post('goods_sn');
			$data['cat_id'] = $this->input->post('cat_id');
			$data['brand_id'] = $this->input->post('brand_id');
			$data['shop_price'] = $this->input->post('shop_price');
			$data['market_price'] = $this->input->post('market_price');
			$data['is_promote'] = $this->input->post('is_promote');
			$data['promote_start_time'] = $this->input->post('promote_start_date');
			$data['promote_end_time'] = $this->input->post('promote_end_date');
			
			$data['goods_thumb'] = '';
			$data['goods_desc'] = $this->input->post('goods_desc');
			
			$data['goods_number'] = $this->input->post('goods_number');
			$data['is_best'] = $this->input->post('is_best');
			$data['is_onsale'] = $this->input->post('is_on_sale');
			$data['is_hot'] = $this->input->post('is_hot');
			$data['is_new'] = $this->input->post('is_new');
			$data['add_time'] = time();

			if(!empty($_FILES['goods_img']['name'])) {
				$folder = Date('Ymd', time());
				$dir = './public/uploads/' . $folder . '/';
				if (!is_dir($dir)) {
					mkdir('./public/uploads/' . $folder . '/');
				}
				$config['upload_path'] = $dir;
		        $config['allowed_types'] = 'gif|jpg|png';
		        $config['max_size'] = 100;
		        $config['max_width'] = 1024;
		        $config['max_height'] = 768;
		        $config['encrypt_name'] = true;
		        $this->load->library('upload', $config);
		        if (!$this->upload->do_upload('goods_img')) {
		        	$error = $this->upload->display_errors();
		        	$errors['message'] = $error;
					$errors['url'] = site_url('admin/goods/add');
					$errors['wait'] = 1;
					$this->load->view('message.html', $errors);
		        } else {
		        	$finfo = $this->upload->data();
		        	$data['goods_img'] = '/ci/public/uploads/' . $folder . '/' . $finfo['file_name'];
		        }
			}
			$result = $this->db->insert('ci_goods', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '添加商品失败!';
				$data['url'] = site_url('admin/goods/add');
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '添加商品成功!';
				$data['url'] = site_url('admin/goods/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//显示编辑表单
	public function edit($id) {
		$id = intval($id);
		$data['cats'] = $this->category_model->catTree();
		$query = $this->db->get('ci_brand');
		$data['brands'] = $query->result_array();
		$query = $this->db->get('ci_goods_type');
		$data['types'] = $query->result_array();
		$data['goods'] = $this->db->where(array('goods_id'=>$id))->get('ci_goods')->row_array();
		$this->load->view('goods_edit.html', $data);
	}

	public function modify() {
		$_validate = array(
			array(
				'field' => 'goods_name',
				'label' => '商品名称',
				'rules' => 'required'
			)
		);
		$goods_id = $this->input->post('goods_id');
		$result = $this->db->where(array('goods_id'=>$goods_id))->get('ci_goods')->row_array();
		$logo_url = $result['goods_img'];
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/goods/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['goods_name'] = $this->input->post('goods_name');
			$data['goods_sn'] = $this->input->post('goods_sn');
			$data['cat_id'] = $this->input->post('cat_id');
			$data['brand_id'] = $this->input->post('brand_id');
			$data['shop_price'] = $this->input->post('shop_price');
			$data['market_price'] = $this->input->post('market_price');
			$data['is_promote'] = $this->input->post('is_promote');
			$data['promote_start_time'] = $this->input->post('promote_start_date');
			$data['promote_end_time'] = $this->input->post('promote_end_date');
			
			$data['goods_thumb'] = '';
			$data['goods_desc'] = $this->input->post('goods_desc');
			
			$data['goods_number'] = $this->input->post('goods_number');
			$data['is_best'] = $this->input->post('is_best');
			$data['is_onsale'] = $this->input->post('is_on_sale');
			$data['is_hot'] = $this->input->post('is_hot');
			$data['is_new'] = $this->input->post('is_new');
			$data['add_time'] = time();
			if(!empty($_FILES['goods_img']['name'])) {
				$folder = Date('Ymd', time());
				$dir = './public/uploads/' . $folder . '/';
				if (!is_dir($dir)) {
					mkdir('./public/uploads/' . $folder . '/');
				}
				$config['upload_path'] = $dir;
		        $config['allowed_types'] = 'gif|jpg|png';
		        $config['max_size'] = 100;
		        $config['max_width'] = 1024;
		        $config['max_height'] = 768;
		        $config['encrypt_name'] = true;
		        $this->load->library('upload', $config);
		        if (!$this->upload->do_upload('goods_img')) {
		        	$error = $this->upload->display_errors();
		        	$errors['message'] = $error;
					$errors['url'] = site_url('admin/goods/add');
					$errors['wait'] = 1;
					$this->load->view('message.html', $errors);
		        } else {
		        	$finfo = $this->upload->data();
		        	$data['goods_img'] = '/ci/public/uploads/' . $folder . '/' . $finfo['file_name'];
		        	if (!empty($logo_url)) {
		        		unlink(ltrim($logo_url, '/ci'));
		        	}
		        }
			}

			$result = $this->db->where(array('goods_id'=>$goods_id))->update('ci_goods', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '修改商品信息失败!';
				$data['url'] = site_url('admin/goods/edit/').$goods_id;
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '修改商品信息成功!';
				$data['url'] = site_url('admin/goods/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}

	//删除分类
	public function delete($id) {
		$id = intval($id);
		$result = $this->db->where(array('goods_id'=>$id))->get('ci_goods')->row_array();
		$logo_url = $result['goods_img'];
		$this->db->delete('ci_goods',array('goods_id'=>$id));
		if ($this->db->affected_rows() == 0) {
			$data['message'] = '删除商品失败!';
			$data['url'] = site_url('admin/goods/index');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			if (!empty($logo_url)) {
		        unlink(ltrim($logo_url, '/ci'));
		    }
			$data['message'] = '删除商品成功!';
			$data['url'] = site_url('admin/goods/index');
			$data['wait'] = 1;
			$this->load->view('message.html', $data);
		}
	}

}