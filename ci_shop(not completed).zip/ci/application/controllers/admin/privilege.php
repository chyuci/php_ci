<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Privilege extends CI_Controller {
	public function __construct() {
		parent::__construct();
	
	}
	//展示后台登陆页面
	public function login() {
		/*$vals = array(
			'word'      => rand(1000,9999),
			'img_url'  => base_url().'data/captcha',
			'img_path'   => './data/captcha/',
			'font_path' => './path/to/fonts/texb.ttf',
			'img_width' => '145',
			'img_height'    => 20,
			'expiration'    => 7200,
			'word_length'   => 4,
			'font_size' => 16,
			'img_id'    => 'Imageid',
			'pool'      => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
			// White background and border, black text and red grid
			'colors'    => array(
			'background' => array(255, 255, 255),
			'border' => array(255, 255, 255),
			'text' => array(0, 0, 0),
			'grid' => array(255, 40, 40)
			)
			);
		$data = create_captcha($vals);*/
	
		$this->load->view('login.html');
	}
	//生成验证码
	public function code() {
		$code = create_captcha();
		//将验证码字符串保存到session中
		$this->session->set_userdata('code', $code);
	}
	public function signin() {
		$captcha = strtolower($this->input->post('captcha'));
		$code = strtolower($this->session->code);
		$_validate = array(
			array(
				'field' => 'username',
				'label' => '用户名',
				'rules' => 'required',
				'error' => '用户名必须!'
			),
			array(
				'field' => 'password',
				'label' => '密码',
				'rules' => 'required',
				'errors' => '密码必须!'
			)
		);
		$this->form_validation->set_rules($_validate);
		if($captcha == $code) {
			if ($this->form_validation->run() === false) {
				$data['message'] = validation_errors();
				$data['url'] = site_url('admin/privilege/login');
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$username = $this->input->post('username');
				$password = $this->input->post('password');
				$password = md5(md5($password));
				$condition['admin_name'] = $username;
				$result = $this->db->where($condition)->get('admin');
				
				if ($result->num_rows() > 0) {
					$admin_info = $result->row();
					if ($admin_info->password == $password) {
						$this->session->set_userdata('admin',$username);
						redirect('admin/main/index');
					} else {
						$data['message'] = '密码错误,请重新填写!';
						$data['url'] = site_url('admin/privilege/login');
						$data['wait'] = 3;
						$this->load->view('message.html', $data);
					}
				} else {
					$data['message'] = '用户名不存在,请重新填写!';
					$data['url'] = site_url('admin/privilege/login');
					$data['wait'] = 3;
					$this->load->view('message.html', $data);
				}
				
			}
		} else {
			$data['message'] = '验证码错误,请重新填写!';
			$data['url'] = site_url('admin/privilege/login');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		}
	}

	public function logout() {
		$array_items = array('admin', 'code');
		$this->session->unset_userdata($array_items);
		redirect('admin/privilege/login');
	}
}