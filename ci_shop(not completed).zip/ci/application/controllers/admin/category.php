<?php
class Category extends Admin_Controller {
	public function __construct() {
		parent::__construct();
	}
	//显示分类信息
	public function index() {
		$data['cats'] = $this->category_model->catTree();
		$this->load->view('cat_list.html', $data);
	}
	//显示添加表单
	public function add() {
		$data['cats'] = $this->category_model->catTree();
		$this->load->view('cat_add.html', $data);
	}
	public function insert() {
		$_validate = array(
			array(
				'field' => 'cat_name',
				'label' => '分类名称',
				'rules' => 'required',
				'error' => '分类名称必须!'
			)
		);
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/category/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['cat_name'] = $this->input->post('cat_name');
			$data['parent_id'] = $this->input->post('parent_id');
			$data['unit'] = $this->input->post('unit');
			$data['sort_order'] = $this->input->post('sort_order');
			$data['is_show'] = $this->input->post('is_show');
			$data['cat_desc'] = $this->input->post('cat_desc');
			$result = $this->db->insert('ci_category', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '添加分类失败!';
				$data['url'] = site_url('admin/category/add');
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '添加分类成功!';
				$data['url'] = site_url('admin/category/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//显示编辑表单
	public function edit($id) {
		$id = intval($id);
		$data['cats'] = $this->category_model->catTree();
		$data['cate'] = $this->db->where(array('cat_id'=>$id))->get('ci_category')->row_array();
		$this->load->view('cat_edit.html', $data);
	}
	//编辑逻辑处理
	public function modify() {
		$_validate = array(
			array(
				'field' => 'cat_name',
				'label' => '分类名称',
				'rules' => 'required',
				'error' => '分类名称必须!'
			)
		);
		$data['cat_id'] = $this->input->post('cat_id');
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/category/edit/').$data['cat_id'];
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['parent_id'] = $this->input->post('parent_id');
			$ids = $this->category_model->getSubids($data['cat_id']);
			if (in_array($data['parent_id'], $ids)) {
				$data['message'] = '当前类的父类不能为本分类及其子分类';
				$data['url'] = site_url('admin/category/edit/').$data['cat_id'];
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			}
			$data['cat_name'] = $this->input->post('cat_name');
			$data['unit'] = $this->input->post('unit');
			$data['sort_order'] = $this->input->post('sort_order');
			$data['is_show'] = $this->input->post('is_show');
			$data['cat_desc'] = $this->input->post('cat_desc');
			$result = $this->db->where(array('cat_id'=>$data['cat_id']))->update('ci_category', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '修改分类失败!';
				$data['url'] = site_url('admin/category/edit/').$data['cat_id'];
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '修改分类成功!';
				$data['url'] = site_url('admin/category/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//删除分类
	public function delCat($id) {
		$id = intval($id);
		$ids = $this->category_model->getSubids($id);
		if (count($ids) > 1) {//不是叶子节点
			$data['message'] = '您要删除的分类不是叶子节点，请先删除此分类的子类!';
			$data['url'] = site_url('admin/category/index');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		}
		$this->db->delete('ci_category',array('cat_id'=>$id));
		if ($this->db->affected_rows() == 0) {
			$data['message'] = '删除分类失败!';
			$data['url'] = site_url('admin/category/index');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['message'] = '删除分类成功!';
			$data['url'] = site_url('admin/category/index');
			$data['wait'] = 1;
			$this->load->view('message.html', $data);
		}
	}
}