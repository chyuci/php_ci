<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Attribute extends Admin_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('attribute_model');
		$this->load->model('goodstype_model');
	}

	//获取指定类型下的表单
	public function getAttrs($type_id) {
		$type_id = intval($type_id);
		$data['attrs'] = $this->attribute_model->getAttrForm($type_id);
		$this->load->view('ajax_attrs.html', $data);
	}

	//显示品牌信息
	public function index($type_id, $offset='') {
		$type_id = intval($type_id);
		$config['base_url'] = site_url('admin/attribute/index/').$type_id;
		$config['total_rows'] = $this->attribute_model->count_attribute($type_id);
		$config['per_page'] = 5;
		$config['uri_segment'] = 5;//uri第四段为偏移量
		$config['first_link'] = '首页';//首页
		$config['last_link'] = '尾页';//尾页
		$config['prev_link'] = '上一页';//上一页
		$config['next_link'] = '下一页';//下一页
		$this->pagination->initialize($config);
		$limit = $config['per_page'];
		$data['attrs'] = $this->attribute_model->list_attribute($type_id, $limit, $offset);
		$query = $this->db->get('ci_goods_type');
		$data['types'] = $query->result_array();
		$data['pageinfo'] = $this->pagination->create_links();
		$data['type_id'] = $type_id;
		$this->load->view('attribute_list.html', $data);
	}
	//显示添加表单
	public function add($type_id) {
		$query = $this->db->get('ci_goods_type');
		$data['types'] = $query->result_array();
		$data['type_id'] = intval($type_id);
		$this->load->view('attribute_add.html', $data);
	}
	//添加品牌业务逻辑处理
	public function insert() {
		$_validate = array(
			array(
				'field' => 'attr_name',
				'label' => '属性名称',
				'rules' => 'required',
				'error' => '属性名称必须!'
			),
			array(
				'field' => 'attr_type_id',
				'label' => '属性所属商品类型',
				'rules' => 'greater_than[0]',
				'error' => '属性所属商品类型必须!'
			)
		);
		$type_id = $this->input->post('type_id');
		
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/attribute/add/').$type_id;
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['attr_name'] = $this->input->post('attr_name');
			$data['type_id'] = $this->input->post('attr_type_id');
			$data['attr_type'] = $this->input->post('attr_type');
			$data['attr_input_type'] = $this->input->post('attr_input_type');
			$data['attr_value'] = $this->input->post('attr_values');
			
			
			$result = $this->db->insert('ci_attribute', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '添加商品属性失败!';
				$data['url'] = site_url('admin/attribute/add/').$type_id;
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '添加商品属性成功!';
				$data['url'] = site_url('admin/attribute/index/').$type_id;
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//显示编辑表单
	public function edit($id) {
		$id = intval($id);
		$query = $this->db->get('ci_goods_type');
		$data['types'] = $query->result_array();
		$data['attr'] = $this->db->where(array('attr_id'=>$id))->get('ci_attribute')->row_array();
		$this->load->view('attribute_edit.html', $data);
	}
	public function modify() {
		$_validate = array(
			array(
				'field' => 'attr_name',
				'label' => '属性名称',
				'rules' => 'required',
				'error' => '属性名称必须!'
			),
			array(
				'field' => 'attr_type_id',
				'label' => '属性所属商品类型',
				'rules' => 'greater_than[0]',
				'error' => '属性所属商品类型必须!'
			)
		);
		$attr_id = $this->input->post('attr_id');
		$type_id = $this->input->post('type_id');
		
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/attribute/edit/').$attr_id;
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['attr_name'] = $this->input->post('attr_name');
			$data['type_id'] = $this->input->post('attr_type_id');
			$data['attr_type'] = $this->input->post('attr_type');
			$data['attr_input_type'] = $this->input->post('attr_input_type');
			$data['attr_value'] = $this->input->post('attr_values');
			$result = $this->db->where(array('attr_id'=>$attr_id))->update('ci_attribute', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '修改商品属性失败!';
				$data['url'] = site_url('admin/attribute/add/').$type_id;
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '修改商品属性成功!';
				$data['url'] = site_url('admin/attribute/index/').$type_id;
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//删除分类
	public function delete($type_id, $attr_id) {
		$type_id = intval($type_id);
		$attr_id = intval($attr_id);
		$this->db->delete('ci_attribute',array('attr_id'=>$attr_id));
		if ($this->db->affected_rows() == 0) {
			$data['message'] = '删除商品属性失败!';
			$data['url'] = site_url('admin/attribute/index/').$type_id;
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['message'] = '删除商品属性成功!';
			$data['url'] = site_url('admin/attribute/index/').$type_id;
			$data['wait'] = 1;
			$this->load->view('message.html', $data);
		}
	}
}