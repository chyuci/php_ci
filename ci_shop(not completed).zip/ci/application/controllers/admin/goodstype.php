<?php
class Goodstype extends Admin_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('goodstype_model');
	}
	//显示商品类型信息
	public function index($offset = '') {
		$config['base_url'] = site_url('admin/goodstype/index');
		$config['total_rows'] = $this->goodstype_model->count_goodstype();
		$config['per_page'] = 4;
		$config['uri_segment'] = 4;//uri第四段为偏移量
		$config['first_link'] = '首页';//首页
		$config['last_link'] = '尾页';//尾页
		$config['prev_link'] = '上一页';//上一页
		$config['next_link'] = '下一页';//下一页
		$this->pagination->initialize($config);
		$limit = $config['per_page'];
		$data['types'] = $this->goodstype_model->get_goodstype_attr($limit, $offset);
		$data['pageinfo'] = $this->pagination->create_links();
		// var_dump($data['pageinfo']);exit;
		$this->load->view('goods_type_list.html', $data);
	}
	//添加商品类型
	public function add() {
		$this->load->view('goods_type_add.html');
	}
	//添加商品
	public function insert() {
		$_validate = array(
			array(
				'field' => 'type_name',
				'label' => '类型名称',
				'rules' => 'required',
				'error' => '类型名称必须!'
			)
		);
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/goodstype/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['type_name'] = $this->input->post('type_name');
			
			$result = $this->db->insert('ci_goods_type', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '添加商品类型失败!';
				$data['url'] = site_url('admin/goodstype/add');
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '添加商品类型成功!';
				$data['url'] = site_url('admin/goodstype/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//编辑商品类型
	public function edit($id) {
		$id = intval($id);
		$data['type'] = $this->db->where(array('type_id'=>$id))->get('ci_goods_type')->row_array();
		$this->load->view('goods_type_edit.html', $data);
	}
	//编辑商品逻辑处理
	public function modify() {
		$_validate = array(
			array(
				'field' => 'brand_name',
				'label' => '品牌名称',
				'rules' => 'required',
				'error' => '品牌名称必须!'
			)
		);
		$type_id = $this->input->post('type_id');
		$data['type_name'] = $this->input->post('type_name');
		$result = $this->db->where(array('type_id'=>$type_id))->update('ci_goods_type', $data);
		if ($this->db->affected_rows() == 0) {
			$data['message'] = '修改商品类型失败!';
			$data['url'] = site_url('admin/goodstype/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['message'] = '修改商品类型成功!';
			$data['url'] = site_url('admin/goodstype/index');
			$data['wait'] = 1;
			$this->load->view('message.html', $data);
		}
	}
	//删除商品类型
	public function delete($id) {
		$id = intval($id);
		$this->db->delete('ci_goods_type',array('type_id'=>$id));
		if ($this->db->affected_rows() == 0) {
			$data['message'] = '删除商品类型失败!';
			$data['url'] = site_url('admin/goodstype/index');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['message'] = '删除商品类型成功!';
			$data['url'] = site_url('admin/goodstype/index');
			$data['wait'] = 1;
			$this->load->view('message.html', $data);
		}
	}
}