<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Main extends Admin_Controller{
	public function __construct() {
		parent::__construct();
	}
	//展示后台首页页面
	public function index() {
		$this->load->view('index.html');
	}

	//展示头部
	public function top() {
		$this->load->view('top.html');
	}

	//展示左侧菜单栏
	public function menu() {
		$this->load->view('menu.html');
	}

	//展示拉伸按钮
	public function drag() {
		$this->load->view('drag.html');
	}

	//展示内容页
	public function content() {
		$this->load->view('main.html');
	}
}