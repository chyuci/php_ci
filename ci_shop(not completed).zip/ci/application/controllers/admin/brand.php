<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Brand extends Admin_Controller {
	public function __construct() {
		parent::__construct();
	}
	//显示品牌信息
	public function index() {
		$bn = $this->input->post('brand_name');
		if(empty($bn)) {
			$query = $this->db->get('ci_brand');
		} else {
			$query = $this->db->like('brand_name', $bn)->get('ci_brand');
		}
		$data['brands'] = $query->result_array();
		$this->load->view('brand_list.html', $data);
	}
	//显示添加表单
	public function add() {
		$this->load->view('brand_add.html');
	}
	//添加品牌业务逻辑处理
	public function insert() {
		$_validate = array(
			array(
				'field' => 'brand_name',
				'label' => '品牌名称',
				'rules' => 'required',
				'error' => '品牌名称必须!'
			)
		);
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/brand/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['brand_name'] = $this->input->post('brand_name');
			$data['brand_desc'] = $this->input->post('brand_desc');
			$data['url'] = $this->input->post('url');
			$data['sort_order'] = $this->input->post('sort_order');
			$data['is_show'] = $this->input->post('is_show');
			if(!empty($_FILES['logo']['name'])) {
				$folder = Date('Ymd', time());
				$dir = './public/uploads/' . $folder . '/';
				if (!is_dir($dir)) {
					mkdir('./public/uploads/' . $folder . '/');
				}
				$config['upload_path'] = $dir;
		        $config['allowed_types'] = 'gif|jpg|png';
		        $config['max_size'] = 100;
		        $config['max_width'] = 1024;
		        $config['max_height'] = 768;
		        $config['encrypt_name'] = true;
		        $this->load->library('upload', $config);
		        if (!$this->upload->do_upload('logo')) {
		        	$error = $this->upload->display_errors();
		        	$errors['message'] = $error;
					$errors['url'] = site_url('admin/brand/index');
					$errors['wait'] = 1;
					$this->load->view('message.html', $errors);
		        } else {
		        	$finfo = $this->upload->data();
		        	$data['logo'] = '/ci/public/uploads/' . $folder . '/' . $finfo['file_name'];
		        }
			}
			$result = $this->db->insert('ci_brand', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '添加品牌失败!';
				$data['url'] = site_url('admin/brand/add');
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '添加品牌成功!';
				$data['url'] = site_url('admin/brand/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}
	//显示编辑表单
	public function edit($id) {
		$id = intval($id);
		$data['brand'] = $this->db->where(array('brand_id'=>$id))->get('ci_brand')->row_array();
		$this->load->view('brand_edit.html', $data);
	}

	public function modify() {
		$_validate = array(
			array(
				'field' => 'brand_name',
				'label' => '品牌名称',
				'rules' => 'required',
				'error' => '品牌名称必须!'
			)
		);
		$bid = $this->input->post('bid');
		$result = $this->db->where(array('brand_id'=>$bid))->get('ci_brand')->row_array();
		$logo_url = $result['logo'];
		$this->form_validation->set_rules($_validate);
		if ($this->form_validation->run() === false) {
			$data['message'] = validation_errors();
			$data['url'] = site_url('admin/brand/add');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			$data['brand_name'] = $this->input->post('brand_name');
			$data['brand_desc'] = $this->input->post('brand_desc');
			$data['url'] = $this->input->post('url');
			$data['sort_order'] = $this->input->post('sort_order');
			$data['is_show'] = $this->input->post('is_show');
			if(!empty($_FILES['logo']['name'])) {
				$folder = Date('Ymd', time());
				$dir = './public/uploads/' . $folder . '/';
				if (!is_dir($dir)) {
					mkdir('./public/uploads/' . $folder . '/');
				}
				$config['upload_path'] = $dir;
		        $config['allowed_types'] = 'gif|jpg|png';
		        $config['max_size'] = 100;
		        $config['max_width'] = 1024;
		        $config['max_height'] = 768;
		        $config['encrypt_name'] = true;
		        $this->load->library('upload', $config);
		        if (!$this->upload->do_upload('logo')) {
		        	$error = $this->upload->display_errors();
		        	$errors['message'] = $error;
					$errors['url'] = site_url('admin/brand/index');
					$errors['wait'] = 1;
					$this->load->view('message.html', $errors);
		        } else {
		        	$finfo = $this->upload->data();
		        	$data['logo'] = '/ci/public/uploads/' . $folder . '/' . $finfo['file_name'];
		        	if (!empty($logo_url)) {
		        		unlink(ltrim($logo_url, '/ci'));
		        	}
		        }
			}


			$result = $this->db->where(array('brand_id'=>$bid))->update('ci_brand', $data);
			if ($this->db->affected_rows() == 0) {
				$data['message'] = '修改品牌失败!';
				$data['url'] = site_url('admin/brand/add');
				$data['wait'] = 3;
				$this->load->view('message.html', $data);
			} else {
				$data['message'] = '修改品牌成功!';
				$data['url'] = site_url('admin/brand/index');
				$data['wait'] = 1;
				$this->load->view('message.html', $data);
			}
		}
	}

	//删除分类
	public function delete($id) {
		$id = intval($id);
		$result = $this->db->where(array('brand_id'=>$id))->get('ci_brand')->row_array();
		$logo_url = $result['logo'];
		$this->db->delete('ci_brand',array('brand_id'=>$id));
		if ($this->db->affected_rows() == 0) {
			$data['message'] = '删除品牌失败!';
			$data['url'] = site_url('admin/brand/index');
			$data['wait'] = 3;
			$this->load->view('message.html', $data);
		} else {
			if (!empty($logo_url)) {
		        unlink(ltrim($logo_url, '/ci'));
		    }
			$data['message'] = '删除品牌成功!';
			$data['url'] = site_url('admin/brand/index');
			$data['wait'] = 1;
			$this->load->view('message.html', $data);
		}
	}
}