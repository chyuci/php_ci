<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends Home_Controller {
	#显示注册界面
	public function register() {
		$this->load->view('register.html');
	}
	#显示注册界面
	public function login() {
		$this->load->view('login.html');
	}
	//生成验证码
	public function code() {
		$data = array('img_width'=>'100');
		$code = create_captcha($data);
		//将验证码字符串保存到session中
		$this->session->set_userdata('code', $code);
	}
	//注册信息处理
	public function enroll() {
		$captcha = strtolower($this->input->post('code'));
		$code = strtolower($this->session->code);
		$_validate = array(
			array(
				'field' => 'user',
				'label' => '用户名',
				'rules' => 'required'
			),
			array(
				'field' => 'pwd',
				'label' => '密码',
				'rules' => 'required|min_length[6]|max_length[16]|matches[repwd]'
			),
			array(
				'field' => 'repwd',
				'label' => '密码',
				'rules' => 'required|matches[pwd]'
			),
			array(
				'field' => 'email',
				'label' => '电子邮箱',
				'rules' => 'required|valid_email'
			)
		);
		$this->form_validation->set_rules($_validate);
		if($captcha == $code) {
			if ($this->form_validation->run() === false) {
				$data['message'] = validation_errors();
				$data['url'] = site_url('user/register');
				$data['wait'] = 3;
				$this->load->view('error.html', $data);
			} else {
				$data['user_name'] = $this->input->post('user');
				$password = $this->input->post('pwd');
				$data['password'] = md5(md5($password));
				$data['email'] = $this->input->post('email');
				$data['reg_time'] = time();
				$result = $this->db->insert('ci_user', $data);
				
				if ($this->db->affected_rows() == 0) {
					$data['message'] = '用户注册失败!';
					$data['url'] = site_url('user/register');
					$data['wait'] = 3;
					$this->load->view('error.html', $data);
				} else {
					$data['message'] = '用户注册成功!';
					$data['url'] = site_url('user/login');
					$data['wait'] = 1;
					$this->load->view('right.html', $data);
				}
				
			}
		} else {
			$data['message'] = '验证码错误,请重新填写!';
			$data['url'] = site_url('user/register');
			$data['wait'] = 3;
			$this->load->view('error.html', $data);
		}
	}

	#登陆动作
	public function signin() {
		$captcha = strtolower($this->input->post('code'));
		$code = strtolower($this->session->code);
		$_validate = array(
			array(
				'field' => 'user',
				'label' => '用户名',
				'rules' => 'required'
			),
			array(
				'field' => 'pwd',
				'label' => '密码',
				'rules' => 'required|min_length[6]|max_length[16]'
			)
		);
		$this->form_validation->set_rules($_validate);
		if($captcha == $code) {
			if ($this->form_validation->run() === false) {
				$data['message'] = validation_errors();
				$data['url'] = site_url('user/login');
				$data['wait'] = 3;
				$this->load->view('error.html', $data);
			} else {
				$username = $this->input->post('user');
				$password = $this->input->post('pwd');
				$password = md5(md5($password));
				$condition['user_name'] = $username;
				$result = $this->db->where($condition)->get('ci_user');
				
				if ($result->num_rows() > 0) {
					$user_info = $result->row();
					if ($user_info->password == $password) {
						$this->session->set_userdata('user',$username);
						redirect('home/index');
					} else {
						$data['message'] = '密码错误,请重新填写!';
						$data['url'] = site_url('user/login');
						$data['wait'] = 3;
						$this->load->view('error.html', $data);
					}
				} else {
					$data['message'] = '用户名不存在,请重新填写!';
					$data['url'] = site_url('user/login');
					$data['wait'] = 3;
					$this->load->view('error.html', $data);
				}
				
			}
		} else {
			$data['message'] = '验证码错误,请重新填写!';
			$data['url'] = site_url('user/login');
			$data['wait'] = 3;
			$this->load->view('error.html', $data);
		}
	}

	public function signout() {
		$array_items = array('user', 'code');
		$this->session->unset_userdata($array_items);
		redirect('home');
	}
}