<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {

	/**
	 * [insert 添加数据到数据库]
	 * @return [type] [description]
	 */
	public function insert() {

		//获取表单数据
		$data['title'] = $_POST['title'];
		$data['author'] = $_POST['author'];
		$data['content'] = $_POST['content'];
		$data['add_time'] = Date('Y-m-d H:i:s');
		// var_dump($data);
		// exit;
		//调用news_model的方法即可
		if ($this->news_model->add_news($data)) {
			echo '添加成功!';
			redirect(site_url('news/index'));
		} else {
			echo '添加失败!';
			redirect(site_url('news/insert'));
		}
	}

	/**
	 * [index 显示新闻列表]
	 * @return [type] [description]
	 */
	public function index() {
		//调用show_news方法得到数据
		$data['news'] = $this->news_model->show_news();

		//分配得到视图
		$this->load->view('news_list.html', $data);
	}

	/**
	 * [add 展示添加表单]
	 */
	public function add() {
		$this->load->view('add_news.html');
	}


	/**
	 * [edit 修改新闻表单]
	 * @return [type] [description]
	 */
	public function edit($id) {
		$result = $this->news_model->find_one($id);
		// var_dump($result);
		// exit;
		$data['news'] = $result;
		$this->load->view('edit_news.html', $data);
	}

	/**
	 * [modify 修改新闻业务逻辑]
	 * @return [type] [description]
	 */
	public function modify() {
		//获取表单数据
		$data['id'] = $_POST['id'];
		$data['title'] = $_POST['title'];
		$data['author'] = $_POST['author'];
		$data['content'] = $_POST['content'];
		// var_dump($data);
		// exit;
		//调用news_model的方法即可
		if ($this->news_model->update_news($data)) {
			echo '修改成功!';
		} else {
			echo '修改失败!';
		}
	}

	/**
	 * [del 删除新闻]
	 * @param  [type] $id [新闻id]
	 * @return [type]     [description]
	 */
	public function del($id) {
		if ($this->news_model->del_news($id)) {
			echo '删除成功!';
		} else {
			echo '删除失败!';
		}
	}
}
