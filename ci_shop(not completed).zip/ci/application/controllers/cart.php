<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cart extends Home_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('cart');
		$this->load->model('goods_model');
		$this->load->model('category_model');
	}

	public function show() {
		$data['carts'] = $this->cart->contents();
		$data['cates'] = $this->category_model->front_cate();
		// $cat_id = $this->goods_model->get_cat($goods_id);
		// $data['cats'] = $this->goods_model->getParents($cat_id);
		$this->load->view('flow.html', $data);
	}

	//添加商品到购物车
	public function add() {
		$data['id'] = $this->input->post('goods_id');
		$data['name'] = $this->input->post('goods_name');
		$data['qty'] = $this->input->post('goods_nums');
		$data['price'] = $this->input->post('shop_price');
		$carts = $this->cart->contents();
		foreach($carts as $v) {
			if ($v['id'] == $data['id']) {
				$data['qty'] += $v['qty'];
			}
		}
		if($this->cart->insert($data)) {
			//echo 'ok';
			redirect('cart/show');
		} else {
			echo 'error';
		}
	}

	//删除购物车信息
	public function delete($rowid) {
		$data['rowid'] = $rowid;
		$data['qty'] = 0;
		$this->cart->update($data);
		redirect('cart/show');
	}
}