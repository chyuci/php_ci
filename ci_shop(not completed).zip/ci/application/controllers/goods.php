<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Goods extends Home_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('goods_model');
		$this->load->model('category_model');
	}

	public function goods_desc($goods_id) {
		$map['goods_id'] = $goods_id;
		$data['goods'] = $this->goods_model->get_goods($goods_id);
		$data['cates'] = $this->category_model->front_cate();
		$cat_id = $this->goods_model->get_cat($goods_id)['cat_id'];
		$data['cats'] = $this->goods_model->getParents($cat_id);
		$this->load->view('goods.html', $data);
	}
}