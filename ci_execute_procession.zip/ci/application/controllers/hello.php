<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * hello控制器
 */
class Hello extends CI_Controller {
	/*public function index($word) {
		echo $word;
	}*/

	/*public function index() {
		$this->load->view('hello.html');
	}*/

	public function index() {
		$data['title'] = '一叶障目';
		$data['content'] = '一片叶子挡在眼前会让人看不到外面的广阔世界。
		比喻被局部或暂时的现象所迷惑。';
		$this->load->view('hello.html', $data);
	}

}
